/**
   This program computes an estimate of pi by simulating dart throws onto a square.
*/
public class MonteCarlo2 {
   public static void main(String[] args) {  

      //final int TRIES = 10000000;
      final double PI=3.141592;
      final double EPSILON=0.000001;

      double PIestimate=3.0;
      int hits = 0;
      int tries=0;
      //for (int i = 1; i <= TRIES; i++) {  
      while (Math.abs(PIestimate - PI) > EPSILON) {
         // Generate two random numbers between -1 and 1

         double r = Math.random();
         double x = -1 + 2 * r; 
         r = Math.random();
         double y = -1 + 2 * r;         

         // Check whether the point lies in the unit circle

         if (x * x + y * y <= 1) { hits++; }
         tries++;
         PIestimate = 4.0 * hits / tries;
      }

      /*
         The ratio hits / tries is approximately the same as the ratio 
         circle area / square area = pi / 4
      */        

      System.out.println("Estimate for pi after " + tries + " tries: " + PIestimate);
   }
}
