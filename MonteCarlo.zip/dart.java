/**
   This program computes an estimate of pi by simulating dart throws onto a square.
*/
public class dart {
   private int hits = 0;
   private int tries = 0;
   private int TRIES=0;
   final double PI=3.141592;
   //final double EPSILON=0.000001;
  
   public dart (int tries) {
     this.TRIES = tries;
   }

   public void reset () {
      hits = 0;
      tries = 0;
   }

   public double allTries () {  

      double PIestimate=3.0;
      int hits = 0;
      int tries=0;
      for (int i = 1; i <= TRIES; i++) {  
         // Generate two random numbers between -1 and 1

         double r = Math.random();
         double x = -1 + 2 * r; 
         r = Math.random();
         double y = -1 + 2 * r;         

         // Check whether the point lies in the unit circle

         if (x * x + y * y <= 1) { hits++; }
         tries++;
      }
      return (PIestimate = 4.0 * hits / tries);
   }

   public int precisionTries (double epsilon) {

      int i=0;
      double PIestimate=3.0;

      while (Math.abs(PIestimate - PI) > epsilon) {
         double r = Math.random();
         double x = -1 + 2 * r; 
         r = Math.random();
         double y = -1 + 2 * r;         

         // Check whether the point lies in the unit circle
         if (x * x + y * y <= 1) { hits++; }
         tries++;

         PIestimate = 4.0 * hits / tries;
      }
      return (tries);
   }
}
