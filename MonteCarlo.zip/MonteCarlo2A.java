/**
   This program computes an estimate of pi by simulating dart throws onto a square.
*/
public class MonteCarlo2A {
 
   // Driver to exercise the dart class

   public static void main(String[] args) {  

      int tries = 100000;
      double epsilon = 0.0000001;

      dart d = new dart (tries);

      System.out.println("Estimate for pi after " + tries + " tries: " + d.allTries());
      d.reset();
      System.out.println("Tries to get estimate for pi below " + epsilon + " tries: " + 
		d.precisionTries(epsilon));
   }
}
